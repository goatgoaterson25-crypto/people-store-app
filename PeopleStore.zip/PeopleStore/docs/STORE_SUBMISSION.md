# Submitting to Google Play & Apple App Store

This project is **your marketplace**. Putting the PeopleStore Android client (or any app distributed through it) on Google Play / App Store is a separate process.

## Google Play

1. Create a [Google Play Console](https://play.google.com/console) account ($25 one-time).
2. Create an app listing (title, description, screenshots, privacy policy URL).
3. Generate a release keystore and sign the AAB:
   ```bash
   cd android
   ./gradlew bundleRelease
   ```
4. Upload the `.aab` under Production or a testing track.
5. Complete content rating, target audience, and data safety form.
6. Submit for review.

## Apple App Store

1. Enroll in the [Apple Developer Program](https://developer.apple.com) ($99/year).
2. Create the app in App Store Connect.
3. Build and archive with Xcode (or CI), upload via Transporter / Xcode.
4. Fill metadata, screenshots, privacy nutrition labels.
5. Submit for review.

## What this repo gives you

- Working backend + web + Android client source
- APK upload & distribution **inside PeopleStore** (your own store / sideloading)
- Structure ready for signed release builds

It does **not** bypass Apple or Google review, accounts, or policies.
