# Deployment

## Local (Docker)

```bash
cp backend/.env.example backend/.env
docker compose up --build
```

- API: http://localhost:4000  
- Web: http://localhost:3000  
- MinIO console: http://localhost:9001 (minioadmin / minioadmin)

## Production checklist

- [ ] Set strong `JWT_SECRET`
- [ ] Use managed Postgres (or hardened self-hosted)
- [ ] Put MinIO behind TLS or use S3
- [ ] HTTPS termination (Caddy / nginx / cloud load balancer)
- [ ] Restrict CORS to your web domain
- [ ] Change default admin password immediately
- [ ] Enable database backups

## Environment variables (API)

See `backend/.env.example`.
