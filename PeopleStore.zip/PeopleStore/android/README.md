# PeopleStore Android client

Kotlin / Jetpack Compose client shell for the marketplace.

## Status

Skeleton — wire to the same API (`http://10.0.2.2:4000` on emulator).

## Planned screens

1. Catalog (GET `/apps`)
2. App detail + download APK
3. Developer login + upload

## Build

Open this folder in Android Studio, or:

```bash
./gradlew assembleDebug
```

Release AAB for Play Store:

```bash
./gradlew bundleRelease
```

See [../docs/STORE_SUBMISSION.md](../docs/STORE_SUBMISSION.md) for Play Console steps.

## Note

A full production Compose app (auth, downloads, install intents, WorkManager) is the next iteration. The backend and web admin already support the full upload → review → download loop so you can ship the store server-side first.
