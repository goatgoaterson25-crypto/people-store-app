# PeopleStore

A full-stack app marketplace platform.

- **Backend** — Node.js / Express API (auth, apps catalog, APK uploads, admin)
- **Web** — Storefront + admin dashboard
- **Android** — Client app (browse, download, submit)
- **Docker** — One-command local stack

## Quick start

```bash
git clone https://github.com/goatgoaterson25-crypto/PeopleStore.git
cd PeopleStore
cp backend/.env.example backend/.env
docker compose up --build
```

| Service        | URL                         |
|----------------|-----------------------------|
| API            | http://localhost:4000       |
| Web storefront | http://localhost:3000       |
| Admin          | http://localhost:3000/admin |
| Postgres       | localhost:5432              |
| MinIO (files)  | http://localhost:9000       |

Default admin (change immediately):
- email: `admin@peoplestore.local`
- password: `changeme`

Default developer:
- email: `dev@peoplestore.local`
- password: `developer`

## Project layout

```
backend/          Express API + Prisma
web/              Next.js storefront + admin
android/          Kotlin client
docs/             Deployment & store submission notes
```

## What works in this MVP

- User registration / login (JWT)
- Browse apps, search, categories
- Upload APK + metadata (developer role)
- Admin approve / reject submissions
- Download APKs
- Basic Android client shell

## Path to Google Play / App Store

See [docs/STORE_SUBMISSION.md](docs/STORE_SUBMISSION.md).

You still need developer accounts, signing keys, and to pass review — this repo gives you the product and the release build path.
